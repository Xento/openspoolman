GET_VERSION = {"info": {"sequence_id": "0", "command": "get_version"}}
PUSH_ALL = {"pushing": {"sequence_id": "0", "command": "pushall"}}
AMS_FILAMENT_SETTING = {"print":
  {
    "sequence_id": "0",
    "command": "ams_filament_setting",
    "ams_id": None,
    "tray_id": None,
    "tray_color": None,
    "nozzle_temp_min": None,
    "nozzle_temp_max": None,
    "tray_type": None,
    "setting_id": "",
    "tray_info_idx": None
  }
}
